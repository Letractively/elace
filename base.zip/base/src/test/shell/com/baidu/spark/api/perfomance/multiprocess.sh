#!/bin/sh
for i in `seq 1 100`;do
  nohup sh press.sh $i 2>&1 &
done
