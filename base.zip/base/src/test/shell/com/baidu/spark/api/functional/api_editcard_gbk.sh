#!/bin/sh

if [ $# -le 3 ]
then
        echo "args not right."
        exit 1
fi

username=$1
password=$2
#echo "u:pw="$username:$password

shift
shift

space=$1
#echo "space="$space
shift

card=$1
#echo "card="$card
shift

fieldsValue=""

while [ $# -gt 0 ]; do
        temp=`echo $1|iconv -f gbk -t utf-8`
        fieldsValue="$fieldsValue -d fields=\"$temp\""
        shift
done
#echo "fieldsValue="$fieldsValue

command="curl $fieldsValue \"http://db-iit-qa06.vm.baidu.com/api/spaces/$space/cards/$card?u=$username&pw=$password\" -X POST"

#echo "command="$command
bash -c "$command"