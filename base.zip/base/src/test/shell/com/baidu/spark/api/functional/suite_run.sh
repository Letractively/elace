#!/bin/sh
rm -rf log/$1.*
#echo '<?xml version="1.0" encoding="UTF-8"?>' >> log/$1.xml
#echo '<testsuite>' >> log/$1.xml

TOTAL_NUM=0
PASSED_NUM=0
FAILED_NUM=0

while read line
do
  echo $line
  sh case_run.sh $1.result $line
  FAILED_NUM=`expr $FAILED_NUM + $?`
  TOTAL_NUM=`expr $TOTAL_NUM + 1`
done < $1.data

echo "TOTAL:    "$TOTAL_NUM
echo "FAILED:   "$FAILED_NUM
if [[ "$FAILED_NUM" -eq "0" ]]
then
  exit 0
else
  exit 1
fi