#!/bin/sh
for i in `seq 1 100`;do
  sh ec_gbk.sh sparkcase 75 "user=sunyi_qa" "text=process${1}str${i}"
done
