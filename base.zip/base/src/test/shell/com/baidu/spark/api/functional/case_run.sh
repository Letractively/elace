#!/bin/sh


function logBasicResult() {
  {
    echo "############################"
    echo "TITLE:        "$CASE_TITLE
    echo "input:        "$INPUT
    echo "expect:       "$EXPECT_CODE
    echo "result:       "$result
    if [[ "$status" -ne "0" ]]
    then
      cat log/$$.log
      echo
    fi
    echo "############################"
  } >> log/$REPORT
}

function logJunitXMLResult() {
  {
    echo '  <testcase name="'$CASE_TITLE'"></testcase>'
  } >> log/$REPORT
}

if [ $# -le 6 ]
then
        echo "args not right."
        exit 254
fi

echo "--------------"
echo $*

REPORT=$1
shift

CASE_TITLE=$1