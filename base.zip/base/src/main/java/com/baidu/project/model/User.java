package com.baidu.project.model;

public class User {
	
	private Long id;
	/**
	 * 
	 * @return
	 */
	public Long getId(){
		return id;
	}
}
