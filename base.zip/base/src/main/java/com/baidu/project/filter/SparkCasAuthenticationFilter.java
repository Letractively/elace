package com.baidu.project.filter;

import org.jasig.cas.client.proxy.ProxyGrantingTicketStorage;
import org.jasig.cas.client.util.CommonUtils;
import org.jasig.cas.client.validation.Assertion;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.cas.ServiceProperties;
import org.springframework.security.cas.web.CasAuthenticationFilter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.authentication.session.NullAuthenticatedSessionStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;

import com.baidu.project.model.User;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Processes a CAS service ticket.
 * <p>
 * A service ticket consists of an opaque ticket string. It arrives at this filter by the user's browser successfully
 * authenticating using CAS, and then receiving a HTTP redirect to a <code>service</code>. The opaque ticket string is
 * presented in the <code>ticket</code> request parameter. This filter monitors the <code>service</code> URL so it can
 * receive the service ticket and process it. The CAS server knows which <code>service</code> URL to use via the
 * {@link ServiceProperties#getService()} method.
 * <p>
 * Processing the service ticket involves creating a <code>UsernamePasswordAuthenticationToken</code> which
 * uses {@link #CAS_STATEFUL_IDENTIFIER} for the <code>principal</code> and the opaque ticket string as the
 * <code>credentials</code>.
 * <p>
 * The configured <code>AuthenticationManager</code> is expected to provide a provider that can recognise
 * <code>UsernamePasswordAuthenticationToken</code>s containing this special <code>principal</code> name, and process
 * them accordingly by validation with the CAS server.
 * <p>
 * By configuring a shared {@link ProxyGrantingTicketStorage} between the {@link org.jasig.cas.client.validation.TicketValidator} and the
 * CasAuthenticationFilter one can have the CasAuthenticationFilter handle the proxying requirements for CAS. In addition, the
 * URI endpoint for the proxying would also need to be configured (i.e. the part after protocol, hostname, and port).
 * <p>
 * By default this filter processes the URL <tt>/j_spring_cas_security_check</tt>.
 *
 * @author Ben Alex
 * @author 田雨松 在doFilter方法中增加了一段代码, 以支持对URL中,#的特殊处理.
 */
public class SparkCasAuthenticationFilter extends CasAuthenticationFilter {

	private boolean continueChainBeforeSuccessfulAuthentication = false;

    private SessionAuthenticationStrategy sessionStrategy = new NullAuthenticatedSessionStrategy();

	//added by adun
	/**
	 * 记录哪些url是需要对#后的内容进行保存处理
	 */
	private List<String> uriSegments;
	{
		uriSegments = new ArrayList<String>();
		uriSegments.add("/cards/list");
		uriSegments.add("/spaceviews");
		uriSegments.add("/cards/hierarchy");
		uriSegments.add("/cards/wall");
		uriSegments.add("/roadmap/project");
	}
	//added by adun end

    /**
     * Invokes the {@link #requiresAuthentication(HttpServletRequest, HttpServletResponse) requiresAuthentication}
     * method to determine whether the request is for authentication and should be handled by this filter.
     * If it is an authentication request, the
     * {@link #attemptAuthentication(HttpServletRequest, HttpServletResponse) attemptAuthentication} will be invoked
     * to perform the authentication. There are then three possible outcomes:
     * <ol>
     * <li>An <tt>Authentication</tt> object is returned.
     * The configured {link SessionAuthenticationStrategy} will be invoked followed by the
     * {@link #successfulAuthentication(HttpServletRequest, HttpServletResponse, Authentication)
     * successfulAuthentication} method</li>
     * <li>An <tt>AuthenticationException</tt> occurs during authentication.
     * The {@link #unsuccessfulAuthentication(HttpServletRequest, HttpServletResponse, AuthenticationException)
     * unsuccessfulAuthentication} method will be invoked</li>
     * <li>Null is returned, indicating that the authentication process is incomplete.
     * The method will then return immediately, assuming that the subclass has done any necessary work (such as
     * redirects) to continue the authentication process. The assumption is that a later request will be received
     * by this method where the returned <tt>Authentication</tt> object is not null.
     * </ol>
     */
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;


	    //added by Adun.
	    //Inorder to take "#" and conditions behind it, we generate a parameter named "_redirect_" by js,
	    //which is the URLEncoding-form of current URL including "#"-part
	    //after login, it will redirect to the page defined by "_redirect_"
	    User user = null;
		String redirect = request.getParameter("_redirect_");
        if (user != null){
	        if (redirect != null) {
				response.sendRedirect(redirect);
				return;
	        }
        }else{
	        if (redirect == null && isIncludeUrl(request)) {
				response.setContentType("text/html;charset=UTF-8");
				StringBuilder jsContent = new StringBuilder();
				jsContent.append("<script type=\"text/javascript\">")
					.append("var fhref=window.location.href.replace(/;jsessionid=[^\\?&$]*/ig,\"\");")
					.append("var href=fhref.replace(/#(.*?)$/g,\"\");")
					.append("window.location.href=href+(href.indexOf(\"?\")>-1?\"&\":\"?\")+\"_redirect_=\"+encodeURIComponent(fhref);")
					.append("</script>");
				response.getWriter().write(jsContent.toString());
				response.getWriter().flush();
				return;
			}
        }
		//added by adun till this.

        if (!requiresAuthentication(request, response)) {
            chain.doFilter(request, response);
            return;
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Request is to process authentication");
        }

        Authentication authResult;

        try {
            authResult = attemptAuthentication(request, response);
            if (authResult == null) {
                // return immediately as subclass has indicated that it hasn't completed authentication
                return;
            }
            sessionStrategy.onAuthentication(authResult, request, response);
        }
        catch (AuthenticationException failed) {
            // Authentication failed
            unsuccessfulAuthentication(request, response, failed);

            return;
        }

        // Authentication success
        if (continueChainBeforeSuccessfulAuthentication) {
            chain.doFilter(request, response);
        }

        successfulAuthentication(request, response, authResult);
    }

	/**
	 * 判断一个url是否需要对#后的数据进行特殊处理
	 * @param request
	 * @return
	 */
	private boolean isIncludeUrl(HttpServletRequest request){
		String uri = request.getRequestURI();
		for (String uriSegment : uriSegments){
			if (uri.contains(uriSegment)){
				return true;
			}
		}
		return false;
	}
}
