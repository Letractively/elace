package com.baidu.project.dao;

import com.baidu.project.model.Configuration;

/**
 * 系统变量数据接口.
 * 
 * @author shixiaolei
 * 
 */
public interface ConfigurationDao extends GenericDao<Configuration, String> {

}
