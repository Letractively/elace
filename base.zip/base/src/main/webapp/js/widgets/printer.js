/**
 * 卡片墙打印类
 */
(function(){

    var msg = Spark.util.message;

	Spark.widgets.Printer = function( options ) {
        this.options = $.extend({},this.options,options);
        this._init();
    };

	Spark.widgets.Printer.prototype = {

        options : {
            parentDivId : null,
            className : null
        },

        _init : function cardPrint_init(){
            var title = msg("wall.print");
            var printSpan = $("<span>").attr("title",title).addClass(this.options.className).appendTo($("#"+this.options.parentDivId));
            var me = this;
            $(printSpan).bind("click",function(){
                me._print();
            });
        },

		_print : function cardPrint_print(){
            var me = this;
            var swimmingPoolBodys = $("#wall_head td .wall_body_inner");
			var div = $("<div>").attr("style","width:100%");
            var allCardDivs = [];
            $.each(swimmingPoolBodys, function(index, swimmingPoolBody){
                if($(swimmingPoolBody).is(":visible")){
                    var cardDivs = $(swimmingPoolBody).children();
                    allCardDivs = $.merge(allCardDivs,cardDivs);
                }
            }) ;

            if(!allCardDivs.length){
                return;
            }
            for(var i=0; i<allCardDivs.length; i=i+6){
                var table = $("<table>").attr("style","width:98%;margin:auto;page-break-after:always;");
                if(allCardDivs[i]){
                    var tr = $("<tr>").appendTo(table);
                    me._generateTds(tr,allCardDivs,i,i+1);
                }
                if(allCardDivs[i+2]){
                    var tr1 = $("<tr>").appendTo(table);
                    me._generateTds(tr1,allCardDivs,i+2,i+3);
                }
                if(allCardDivs[i+4]){
                    var tr2 = $("<tr>").appendTo(table);
                    me._generateTds(tr2,allCardDivs,i+4,i+5);
                }
                table.appendTo(div);
            }

//            $("body").empty();
//			div.appendTo($("body"));
            div.printArea();
        },

        _generateTds : function cardPrint_generateTds(tr,elements,from,to){
            for(var i=from; i<=to; i++){
                var td = $("<td>").attr("style","width:50%;padding-top:60px;padding-bottom:60px;text-align:center").appendTo(tr);
//                if( i%6 == 0){
//                    td.attr("style",td.attr("style")+";border-width:0 1px 0 0");
//                }
//                if( i%6 == 1){
//                    td.attr("style",td.attr("style")+";border-width:0 0 0 0");
//                }
//                if( i == from && i%6!=0){
//                    td.attr("style",td.attr("style")+";border-width:1px 1px 0 0");
//                }
//                if( i==to && i%6!=1){
//                    td.attr("style",td.attr("style")+";border-width:1px 0 0 0");
//                }
                if(elements[i]){
                    var element = $(elements[i]).clone();
                    var colorDiv = element.find(".color");
                    colorDiv.attr("style",colorDiv.attr("style")+";height:226px;width:12px");
                    var contentDiv = element.find(".wall-right");
                    contentDiv.attr("style","width:288px;padding-left:12px");
                    var sequenceSpan = element.find(".card-sequence");
                    sequenceSpan.attr("style","height:45px;");
                    var tipSpan = element.find(".wall-tip");
                    tipSpan.attr("style","height:45px;font-size:27px");
                    element.attr("style","float:none;width:300px;height:222px;margin:auto;line-height:45px;font-size:36px;").appendTo(td);
                }
            }
        }
	}
})();
