/**
 * 发送邮件小组建
 * 用于嵌入卡片编辑和讨论编辑中
 * @author fangrui
 */
(function(){
	
	/** 国际化工具函数 */
	var i18n = Spark.util.message;
	
	Spark.widgets.EmailWidget = function(options){
		this.options = $.extend({},this.options,options);
		this.init();
		this.options.notifyMessageDefault = i18n('emailWidget.notifyMessageDefault');
	};
	
	Spark.widgets.EmailWidget.prototype = {
		
		options : {
            //widget 在级联样式表中的key
            cssClass : '',
			//是否打开组件，false则隐藏组件
			noticeSwitch : true,
			//是否展示是否勾选默认抄送空间
			enable : false,
			//包含widget的父级HTML Element id
			parentEleId : null,
			//widget id
			widgetId : 'emailId',
			//对象内保存添加suggest功能的inoput的jquery对象
			autosuggestInputObj : null,
			//小空间的宽度
			width : "100%",
			//后台传入的默认发送邮件人员字符串
			defaultEmails : "",
			//默认填写的邮件
			emails : "",
			//默认填写的附加信息
			notifyMessage: "",
			//附加内容框中默认显示的文字
			notifyMessageDefault: "",
            /**
             * 动态生成的check框
             * 数组内元素为json{id:"",displayValue:"",checked:true/false}
             */
           dynamicElements : []
		},
		
		/**
		 * 初始化方法
		 * 新建widget html模板
		 * 初始化数据
		 * 初始化联动规则
		 */
		init : function EmailWidget_init(){
			this.initHTMlTemplate();
            this.dynamicRenderHtml();
			this.renderValue();
			this.renderEvent();
		},
		
		/**
		 * 初始化widget html模板
		 */
		initHTMlTemplate : function EmailWidget_initHTMLTemplate(){
			var htmlBuffer = [];
			var style = "width:"+ this.options.width;
			var emailWidget = $("<div></div>").attr("id",this.options.widgetId).attr("style",style)
				.addClass("emailWidget").addClass(this.options.cssClass).appendTo($("#"+this.options.parentEleId));
			
				htmlBuffer.push("<div class='title'>");
					htmlBuffer.push("<span>");
						htmlBuffer.push("<input type='checkbox' id='noticeSwitch' name='_noticeSwitch' value='true'/>");
						htmlBuffer.push("<span>" + i18n('emailWidget.saveNotify') + "</span>");
						htmlBuffer.push("<span id='error' style='display:none' class='emailError'></span>");
					htmlBuffer.push("</span>");
				htmlBuffer.push("</div>");
				
				htmlBuffer.push("<div id='widgetContent' style='display:none' class='content'>");

                    htmlBuffer.push("<div id='systemEmailDiv'>");
                        htmlBuffer.push("<div class='left'>");
							htmlBuffer.push("<div class='emailNote'>");
                                htmlBuffer.push(i18n('emailWidget.notify'));
                            htmlBuffer.push("</div>");
					    htmlBuffer.push("</div>");

                        htmlBuffer.push("<div class='right'>");
                            htmlBuffer.push("<div class='email' id='emailContainer'>");
                            /*
                            期间动态渲染checkbox框
                            */
                            htmlBuffer.push("</div>");
                            htmlBuffer.push("<div id='otherEmailDiv'>");
                               htmlBuffer.push("<span class='otherEamilNote'><label for='notifyEmails'>" + i18n('emailWidget.notifyEmails') + ":</label></span>");
                               htmlBuffer.push("<span class='otherEmail'><input name='_emails' id='emails'/></span>");
                               htmlBuffer.push("<span class='patternNotice'>(" + i18n('emailWidget.emails.notice') + ")</span>");
                            htmlBuffer.push("</div>");
                        htmlBuffer.push("</div>")
                        htmlBuffer.push("<div class='clear-both'></div>");
					htmlBuffer.push("</div>");

					htmlBuffer.push("<div class='addition'>");
                        htmlBuffer.push("<div class='left'>");
                            htmlBuffer.push("<span class='switchDiv'>");
                                htmlBuffer.push("<a id='notifyMessageSwitch'>" + i18n('emailWidget.notifyMessageSwitch') + "</a>");
                            htmlBuffer.push("</span>");
                        htmlBuffer.push("</div>");

                        htmlBuffer.push("<div class='right'>")
                            htmlBuffer.push("<span class='notifyMessageDiv' id='notifyMessageDiv'>");
                                htmlBuffer.push("<textarea id='notifyMessage' name='notifyMessage' class='notifyMessage notifyMessageNotice'></textarea>");
                            htmlBuffer.push("</span>");
                        htmlBuffer.push("</div>");
					htmlBuffer.push("</div>");
                    htmlBuffer.push("<div class='clear-both'></div>")
				htmlBuffer.push("</div>");
				
			//将生成的模板添加到对应的页面元素下面
			emailWidget.append(htmlBuffer.join(""));
			//提供autosuggest功能的input框对象，传入Spark.thirdparty.multiUserSuggest,用于验证输入框中内容是否正确
			this.options.autosuggestInputObj = $("#emails");
		},

        /**
         * 动态添加收件人checkbox
         */
       dynamicRenderHtml : function EmailWidget_dynamicRenderHtml(){
            var emailContainer = $("#emailContainer");
            $.each(this.options.dynamicElements, function(index, userCheckBoxEmail){
                var userPropertySpan = $("<span>").addClass("userEmailSpan").appendTo(emailContainer);
                $("<input type='checkbox'>").attr("name","userCheckBoxEmail").attr("value",userCheckBoxEmail.id)
                    .attr("id","userCheckBoxEmail_"+userCheckBoxEmail.id).attr("checked",userCheckBoxEmail.checked)
                    .appendTo(userPropertySpan);
                $("<span>").text(userCheckBoxEmail.displayValue).appendTo(userPropertySpan);
            });

            var defaultEmailNotice = this.options.defaultEmails==""?i18n('emailWidget.defaultEmails.none'):this.options.defaultEmails;
            var defaultEmailSpan =  $("<span>").addClass("userEmailSpan").appendTo(emailContainer);
            $("<input type='checkbox'>").attr("name","_enable").attr("id","enable").attr("value","true")
                .appendTo(defaultEmailSpan);
            $("<span>").text(i18n('emailWidget.defaultEmails') + "(" + defaultEmailNotice + ")").appendTo(defaultEmailSpan);
       },
		
		/**
		 * 初始化widget数据
		 */
		renderValue : function EmailWidget_renderValue(){
			if(this.options.noticeSwitch){
				$("#noticeSwitch").attr("checked",true);
				$("#widgetContent").show();
				if(this.options.enable){
					$("#enable").attr("checked",true);
				}
				$("#emails").val(this.options.emails);
				if(this.options.notifyMessage){
					$("#notifyMessage").val(this.options.notifyMessage);
					$("#notifyMessageDiv").show();
				}
			}
		},
		
		/**
		 * 初始化联动规则
		 */
		renderEvent : function EmailWidget_renderEvent(){
			var me = this;
			$("#noticeSwitch").bind("click",function(){
				if($(this).attr("checked")){
					$("#enable").attr("checked",true);
					$("#widgetContent").show();
				}else{
					$("#widgetContent").hide();
				}
			});
			
			$("#notifyMessageSwitch").bind("click",function(){
				$('.notifyMessageDiv').toggle("fast",function(){
					if($(this).is(":visible")){
						if(!me.options.notifyMessage){
							$("#notifyMessage").val(me.options.notifyMessageDefault);
						}
					}
				});
			});
			
			$("#notifyMessage").bind("click",function(){
				if($(this).val() == me.options.notifyMessageDefault){
					$(this).removeClass('notifyMessageNotice').addClass('notifyMessageInput');
					$(this).val("");
				}
			}).bind("blur",function(){
				if( !$(this).val() ){
					$(this).removeClass('notifyMessageInput').addClass('notifyMessageNotice');
					$(this).val(me.options.notifyMessageDefault);
				}
			});
			
			Spark.thirdparty.multiUserSuggest(this.options.autosuggestInputObj);
		},

		/**
		 * 得到widget里所有控件的值
		 * @return json
		 */
		getParams : function EmailWidget_getParams(){
            var userCheckBoxEmails = $("#emailContainer .userEmailSpan input");
            var userCheckBoxEmailValues = [];
            $.each(userCheckBoxEmails, function(index,element){
                if($(element).attr("name") == "userCheckBoxEmail" && $(element).attr("checked") == true){
                    value = $(element).val();
                    userCheckBoxEmailValues.push(value);
                }
            });
            var result = {
                noticeSwitch : $("#noticeSwitch").attr("checked"),
                enable : $("#enable").attr("checked"),
                userCheckBoxEmailValues : userCheckBoxEmailValues.join(","),
                emails : this.options.autosuggestInputObj.val(),
                notifyMessage : $("#notifyMessage").val()
            };
            return result;
		},
		
		/**
		 * 清空widget里所有控件的值
		 */
		clear : function EmailWidget_clear(){
			$("#enable").attr("checked",false);
			$("#noticeSwitch").attr("checked",false);
			$("#emails").val("");
			$("#notifyMessage").val("");
		},
		
		/**
		 * 清空widget里所有控件的值
		 * 并隐藏widget到body标签下
		 */
		hideUnderBody : function EamilWidget_hideUnderBody(){
			$('#'+this.options.widgetId).hide().appendTo($('body'));
		},
		
		/**
		 * 重新初始化widget数据
		 * 并在摸个标签下显示widget
		 */
		showUnderEle : function EamilWidget_showUnderEle(JqueryObj){
			$('#'+this.options.widgetId).appendTo(JqueryObj).show();
        },
		
		/**
		 * 验证用户输入的人员是否合法
		 */
		validate : function EmailWidget_validate(){
			var result = Spark.thirdparty.multiUserSuggest.validate(this.options.autosuggestInputObj);
			if( result.result == 'true' ){
				$("#error").text("").hide();
				if( $("#notifyMessage").val() == this.options.notifyMessageDefault ){
					$("#notifyMessage").val("");
				}
				return true;
			}else{
				var notice = i18n('emailWidget.emails.error')+result.info;
				$("#error").text(notice).show();
				return false;
			}
		}
		
	}
})();