SET FOREIGN_KEY_CHECKS=0;

#
# tables for the `roadmap_plugin` :
#
CREATE TABLE `plugin_roadmap_space_mapping` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '映射ID',
  `space_id` bigint(20) NOT NULL COMMENT '空间ID',
  `section_name` varchar(512) NOT NULL,
  `space_view_id` bigint(20) NOT NULL,
  `roadmap_property_id` bigint(20) default NULL COMMENT '用于记录卡片所属 项目/发布 等信息的自定义字段',
  `status_property_id` bigint(20) default NULL COMMENT ' 用于记录卡片状态的自定义字段',
  `available` tinyint(3) unsigned NOT NULL default '1' COMMENT '是否可用',
  PRIMARY KEY  (`id`),
  KEY `plugin_wiki_space_mapping_space` (`space_id`),
  CONSTRAINT `plugin_roadmap_space_mapping_space` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;