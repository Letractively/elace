#
#给release roadmap的space_view url增加'?sectionName=release' 
#
update space_view set view_url=concat(view_url,'?sectionName=release') where id in(select space_view_id from plugin_roadmap_space_mapping m where m.section_name='release');