# SQL Manager 2007 for MySQL 4.1.2.1
# ---------------------------------------
# Host     : bb-iit-dev01.bb01.baidu.com
# Port     : 8888
# Database : spark-beta


SET FOREIGN_KEY_CHECKS=0;


#
# Structure for the `acl_class` table : 
#

CREATE TABLE `acl_class` (
  `ID` bigint(20) NOT NULL auto_increment,
  `CLASS` varchar(100) NOT NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `SYS_IDX_49` (`ID`),
  UNIQUE KEY `SYS_IDX_UNIQUE_UK_2_51` (`CLASS`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

#
# Structure for the `acl_sid` table : 
#

CREATE TABLE `acl_sid` (
  `ID` bigint(20) NOT NULL auto_increment,
  `PRINCIPAL` tinyint(1) NOT NULL,
  `SID` varchar(100) NOT NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `SYS_IDX_46` (`ID`),
  UNIQUE KEY `SYS_IDX_UNIQUE_UK_1_48` (`SID`,`PRINCIPAL`)
) ENGINE=InnoDB AUTO_INCREMENT=850 DEFAULT CHARSET=utf8;

#
# Structure for the `acl_object_identity` table : 
#

CREATE TABLE `acl_object_identity` (
  `ID` bigint(20) NOT NULL auto_increment,
  `OBJECT_ID_CLASS` bigint(20) NOT NULL,
  `OBJECT_ID_IDENTITY` bigint(20) NOT NULL,
  `PARENT_OBJECT` bigint(20) default NULL,
  `OWNER_SID` bigint(20) default NULL,
  `ENTRIES_INHERITING` tinyint(1) NOT NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `SYS_IDX_52` (`ID`),
  UNIQUE KEY `SYS_IDX_UNIQUE_UK_3_54` (`OBJECT_ID_CLASS`,`OBJECT_ID_IDENTITY`),
  KEY `SYS_IDX_55` (`PARENT_OBJECT`),
  KEY `SYS_IDX_57` (`OBJECT_ID_CLASS`),
  KEY `SYS_IDX_59` (`OWNER_SID`),
  CONSTRAINT `FOREIGN_FK_1` FOREIGN KEY (`PARENT_OBJECT`) REFERENCES `acl_object_identity` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FOREIGN_FK_2` FOREIGN KEY (`OBJECT_ID_CLASS`) REFERENCES `acl_class` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FOREIGN_FK_3` FOREIGN KEY (`OWNER_SID`) REFERENCES `acl_sid` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7987 DEFAULT CHARSET=utf8;

#
# Structure for the `acl_entry` table : 
#

CREATE TABLE `acl_entry` (
  `ID` bigint(20) NOT NULL auto_increment,
  `ACL_OBJECT_IDENTITY` bigint(20) NOT NULL,
  `ACE_ORDER` int(11) NOT NULL,
  `SID` bigint(20) NOT NULL,
  `MASK` int(11) NOT NULL,
  `GRANTING` tinyint(1) NOT NULL,
  `AUDIT_SUCCESS` tinyint(1) NOT NULL,
  `AUDIT_FAILURE` tinyint(1) NOT NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `SYS_IDX_61` (`ID`),
  UNIQUE KEY `SYS_IDX_UNIQUE_UK_4_63` (`ACL_OBJECT_IDENTITY`,`ACE_ORDER`),
  KEY `SYS_IDX_64` (`ACL_OBJECT_IDENTITY`),
  KEY `SYS_IDX_66` (`SID`),
  CONSTRAINT `FOREIGN_FK_4` FOREIGN KEY (`ACL_OBJECT_IDENTITY`) REFERENCES `acl_object_identity` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FOREIGN_FK_5` FOREIGN KEY (`SID`) REFERENCES `acl_sid` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3049 DEFAULT CHARSET=utf8;

#
# Structure for the `users` table : 
#

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '用户id',
  `uic_id` bigint(20) default NULL COMMENT 'uicid',
  `username` varchar(255) NOT NULL,
  `name` varchar(255) default NULL COMMENT '用户姓名',
  `email` varchar(255) default NULL COMMENT '邮箱',
  `locked` tinyint(1) default NULL COMMENT '是否有效',
  PRIMARY KEY  (`id`),
  KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=28524 DEFAULT CHARSET=utf8 COMMENT='用户表';

#
# Structure for the `spaces` table : 
#

CREATE TABLE `spaces` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '空间ID',
  `name` varchar(255) default NULL COMMENT '空间名称',
  `prefix_code` varchar(255) default NULL COMMENT '空间简称',
  `description` text,
  `type` int(11) default NULL COMMENT '空间类型',
  `is_public` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `prefix_code` (`prefix_code`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8 COMMENT='需求空间';

#
# Structure for the `card_type` table : 
#

CREATE TABLE `card_type` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '卡片类型id',
  `local_id` bigint(20) NOT NULL COMMENT '空间内标识',
  `name` varchar(255) default NULL COMMENT '卡片类型名称',
  `space_id` bigint(20) default NULL COMMENT '所属空间',
  `parent_card_type_id` bigint(20) default NULL COMMENT '上级卡片类型id',
  `recursive` tinyint(1) default NULL COMMENT '是否级联',
  `color` varchar(10) default '#FFF' COMMENT '显示颜色',
  PRIMARY KEY  (`id`),
  KEY `card_type_space_id` (`space_id`),
  KEY `card_type_parent_card_type_id` (`parent_card_type_id`),
  KEY `card_type_index` (`space_id`,`local_id`),
  CONSTRAINT `card_type_parent_card_type_id` FOREIGN KEY (`parent_card_type_id`) REFERENCES `card_type` (`id`),
  CONSTRAINT `card_type_space_id` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=457 DEFAULT CHARSET=utf8 COMMENT='卡片类型表';

#
# Structure for the `card_history` table : 
#

CREATE TABLE `card_history` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '历史ID',
  `card_id` bigint(20) default NULL COMMENT '对应卡片ID',
  `op_user_id` bigint(20) default NULL COMMENT '操作人',
  `op_time` datetime default NULL COMMENT '操作时间',
  `op_type` int(11) default NULL COMMENT '操作类型',
  `title` varchar(1024) default NULL COMMENT '标题',
  `detail` mediumtext COMMENT '描述',
  `data` mediumtext COMMENT '当前状态的序列化文本',
  `diff_data` mediumtext COMMENT '与上个版本的diff信息',
  PRIMARY KEY  (`id`),
  KEY `card_history_card_id` (`card_id`),
  KEY `card_history_op_user_id` (`op_user_id`),
  CONSTRAINT `card_history_card_id` FOREIGN KEY (`card_id`) REFERENCES `card` (`id`),
  CONSTRAINT `card_history_op_user_id` FOREIGN KEY (`op_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20427 DEFAULT CHARSET=utf8 COMMENT='卡片更新历史表';

#
# Structure for the `icafe_project` table : 
#

CREATE TABLE `icafe_project` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '标识',
  `icafe_project_id` bigint(20) NOT NULL COMMENT 'iCafe项目ID',
  `name` varchar(255) default NULL COMMENT 'iCafe项目名称',
  `space_id` bigint(20) default NULL COMMENT '外间，关联到空间',
  PRIMARY KEY  (`id`),
  KEY `icafe_project_space_id` (`space_id`),
  CONSTRAINT `icafe_project_space_id` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8 COMMENT='iCafe的项目表';

#
# Structure for the `card` table : 
#

CREATE TABLE `card` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '卡片ID',
  `space_id` bigint(20) default NULL COMMENT '所属空间',
  `super_id` bigint(20) default NULL COMMENT '上级卡片ID',
  `card_type` bigint(20) default NULL COMMENT '卡片类型',
  `title` varchar(1024) default NULL COMMENT '标题',
  `detail` mediumtext COMMENT '描述',
  `created_user` bigint(20) default NULL COMMENT '创建人',
  `created_time` datetime default NULL COMMENT '创建时间',
  `last_modified_user` bigint(20) default NULL COMMENT '最后更新人',
  `last_modified_time` datetime default NULL COMMENT '最后更新时间',
  `sequence` bigint(11) default NULL COMMENT '卡片序号',
  `history_id` bigint(20) default NULL COMMENT '历史ID',
  `project_id` bigint(20) default NULL COMMENT '可能关联到的iCafe项目',
  PRIMARY KEY  (`id`),
  KEY `card_super_id` (`super_id`),
  KEY `card_card_type` (`card_type`),
  KEY `card_created_user` (`created_user`),
  KEY `card_last_modified_user` (`last_modified_user`),
  KEY `card_project_id` (`project_id`),
  KEY `card_space_id` (`space_id`),
  KEY `card_history_id` (`history_id`),
  KEY `card_index` (`space_id`,`sequence`),
  CONSTRAINT `card_card_type` FOREIGN KEY (`card_type`) REFERENCES `card_type` (`id`),
  CONSTRAINT `card_created_user` FOREIGN KEY (`created_user`) REFERENCES `users` (`id`),
  CONSTRAINT `card_history_id` FOREIGN KEY (`history_id`) REFERENCES `card_history` (`id`),
  CONSTRAINT `card_last_modified_user` FOREIGN KEY (`last_modified_user`) REFERENCES `users` (`id`),
  CONSTRAINT `card_project_id` FOREIGN KEY (`project_id`) REFERENCES `icafe_project` (`id`),
  CONSTRAINT `card_space_id` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`id`),
  CONSTRAINT `card_super_id` FOREIGN KEY (`super_id`) REFERENCES `card` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7783 DEFAULT CHARSET=utf8 COMMENT='卡片';

#
# Structure for the `attachment` table : 
#

CREATE TABLE `attachment` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '附件id',
  `name` varchar(200) NOT NULL COMMENT '附件名',
  `original_name` varchar(200) NOT NULL COMMENT '附件原始文件名',
  `path` varchar(400) NOT NULL COMMENT '附件路径',
  `type` varchar(20) default NULL COMMENT '附件类型',
  `upload_user` bigint(20) default NULL COMMENT '附件上传人',
  `upload_time` datetime default NULL COMMENT '附件上传时间',
  `card_id` bigint(20) default NULL COMMENT '附件所属卡片',
  `status` int(11) default NULL COMMENT '附件状态0表示正常1表示删除',
  `old_attach_id` bigint(20) default NULL COMMENT '附件替换的老附件id',
  `note` text COMMENT '附件备注',
  PRIMARY KEY  (`id`),
  KEY `attachment_user_id` (`upload_user`),
  KEY `attachment_card_id` (`card_id`),
  CONSTRAINT `attachment_user_id` FOREIGN KEY (`upload_user`) REFERENCES `users` (`id`),
  CONSTRAINT `attachment_card_id` FOREIGN KEY (`card_id`) REFERENCES `card` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=724 DEFAULT CHARSET=utf8 COMMENT='附件表';

#
# Structure for the `card_property` table : 
#

CREATE TABLE `card_property` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '卡片属性ID',
  `local_id` bigint(20) NOT NULL COMMENT '空间内标识',
  `space_id` bigint(20) NOT NULL COMMENT '空间ID',
  `name` varchar(255) default NULL COMMENT '属性名称',
  `type` varchar(20) default NULL COMMENT '属性类型',
  `sort` int(11) default NULL COMMENT '属性顺序号',
  `info` text COMMENT '辅助信息',
  `hidden` tinyint(1) default NULL COMMENT '是否隐藏',
  PRIMARY KEY  (`id`),
  KEY `card_property_index` (`space_id`,`local_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1068 DEFAULT CHARSET=utf8 COMMENT='卡片属性表';

#
# Structure for the `card_property_value` table : 
#

CREATE TABLE `card_property_value` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '卡片属性值表',
  `card_id` bigint(20) default NULL COMMENT '卡片ID',
  `card_property_id` bigint(20) default NULL COMMENT '卡片属性ID',
  `type` varchar(20) default NULL COMMENT '值类型',
  `intvalue` bigint(20) default NULL COMMENT '数字型值',
  `strvalue` text COMMENT '字符串值',
  `timevalue` datetime default NULL COMMENT '日期型值',
  PRIMARY KEY  (`id`),
  KEY `card_property_value_card_property_id` (`card_property_id`),
  KEY `card_property_value_card_id` (`card_id`),
  CONSTRAINT `card_property_value_card_id` FOREIGN KEY (`card_id`) REFERENCES `card` (`id`),
  CONSTRAINT `card_property_value_card_property_id` FOREIGN KEY (`card_property_id`) REFERENCES `card_property` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66257 DEFAULT CHARSET=utf8 COMMENT='卡片属性值表';

#
# Structure for the `card_type_property` table : 
#

CREATE TABLE `card_type_property` (
  `card_type_id` bigint(20) NOT NULL default '0',
  `card_property_id` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`card_type_id`,`card_property_id`),
  KEY `card_type_property_type` (`card_type_id`),
  KEY `card_type_property_property` (`card_property_id`),
  CONSTRAINT `card_type_property_card_property` FOREIGN KEY (`card_property_id`) REFERENCES `card_property` (`id`),
  CONSTRAINT `card_type_property_card_type` FOREIGN KEY (`card_type_id`) REFERENCES `card_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for the `configurations` table : 
#

CREATE TABLE `configurations` (
  `config_key` varchar(100) NOT NULL COMMENT '键',
  `config_value` varchar(500) NOT NULL COMMENT '值',
  PRIMARY KEY  (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统环境变量表';

#
# Structure for the `groups` table : 
#

CREATE TABLE `groups` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '用户组id',
  `space_id` bigint(20) default NULL COMMENT '空间id',
  `name` varchar(255) default NULL COMMENT '组名',
  `locked` tinyint(1) default NULL COMMENT '是否失效',
  `exposed` tinyint(1) default NULL COMMENT '是否公开',
  PRIMARY KEY  (`id`),
  KEY `groups_space_id` (`space_id`),
  CONSTRAINT `groups_space_id` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=478 DEFAULT CHARSET=utf8 COMMENT='空间用户组';

#
# Structure for the `group_space` table : 
#

CREATE TABLE `group_space` (
  `map_id` bigint(20) NOT NULL auto_increment COMMENT '映射id',
  `group_id` bigint(20) default NULL COMMENT '组id',
  `space_id` bigint(20) default NULL COMMENT '空间id',
  PRIMARY KEY  (`map_id`),
  KEY `group_space_group_id` (`group_id`),
  KEY `group_space_space_id` (`space_id`),
  CONSTRAINT `group_space_group_id` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  CONSTRAINT `group_space_space_id` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=478 DEFAULT CHARSET=utf8 COMMENT='用户组空间映射';

#
# Structure for the `group_user` table : 
#

CREATE TABLE `group_user` (
  `map_id` bigint(20) NOT NULL auto_increment COMMENT '映射id',
  `group_id` bigint(20) default NULL COMMENT '组id',
  `user_id` bigint(20) default NULL COMMENT '人员id',
  PRIMARY KEY  (`map_id`),
  KEY `group_user_group_id` (`group_id`),
  KEY `group_user_user_id` (`user_id`),
  CONSTRAINT `group_user_group_id` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  CONSTRAINT `group_user_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2427 DEFAULT CHARSET=utf8 COMMENT='用户组人员映射';

#
# Structure for the `space_sequence` table : 
#

CREATE TABLE `space_sequence` (
  `id` bigint(20) NOT NULL,
  `next_card_seq_num` bigint(20) default '1',
  `next_card_type_local_id` bigint(20) default '1',
  `next_card_property_local_id` bigint(20) default '1',
  `next_list_value_local_id` bigint(20) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for the `space_view` table : 
#

CREATE TABLE `space_view` (
  `id` bigint(20) NOT NULL auto_increment COMMENT 'ID',
  `name` varchar(255) default NULL COMMENT '名称',
  `view_url` varchar(2085) default NULL COMMENT 'URL',
  `created_time` date default NULL COMMENT '创建时间',
  `sort` int(11) default NULL COMMENT '顺序',
  `space_id` bigint(20) default NULL COMMENT '所属空间',
  `user_id` bigint(20) default NULL COMMENT '创建用户',
  PRIMARY KEY  (`id`),
  KEY `space_view_space_id` (`space_id`),
  KEY `space_view_user_id` (`user_id`),
  CONSTRAINT `space_view_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `space_view_space_id` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=877 DEFAULT CHARSET=utf8 COMMENT='空间视图收藏表';

#
# Structure for the `spacegroups` table : 
#

CREATE TABLE `spacegroups` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  `description` varchar(512) default NULL,
  `user_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `spacegroups_user` (`user_id`),
  CONSTRAINT `spacegroups_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=595 DEFAULT CHARSET=utf8;

#
# Structure for the `spacegroup_space` table : 
#

CREATE TABLE `spacegroup_space` (
  `id` bigint(20) NOT NULL auto_increment,
  `spacegroup_id` bigint(20) NOT NULL,
  `space_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `spacegroup_space_space` (`space_id`),
  KEY `spacegroup_space_spacegroup` (`spacegroup_id`),
  CONSTRAINT `spacegroup_space_spacegroup` FOREIGN KEY (`spacegroup_id`) REFERENCES `spacegroups` (`id`),
  CONSTRAINT `spacegroup_space_space` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;

#
# Structure for the `card_template` table :  
#

CREATE TABLE `card_template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT  COMMENT 'ID',
  `title` varchar(1024) default NULL COMMENT '标题',
  `detail` mediumtext COMMENT '描述',
  `card_type_id` bigint(20) DEFAULT NULL  COMMENT '卡片类型ID',
  PRIMARY KEY (`id`) ,
  KEY `card_templates_card_type_id`(`card_type_id`),
  CONSTRAINT `card_type_id` FOREIGN KEY (`card_type_id`) REFERENCES `card_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COMMENT '卡片模板' ;

#
# Structure for the `user_view` table : 
#

CREATE TABLE `user_view` (
  `id` bigint(20) NOT NULL auto_increment COMMENT 'ID',
  `name` varchar(255) default NULL COMMENT '名称',
  `view_url` varchar(2085) default NULL COMMENT 'URL',
  `created_time` date default NULL COMMENT '创建时间',
  `sort` int(11) default NULL COMMENT '顺序',
  `space_id` bigint(20) default NULL COMMENT '所属空间',
  `user_id` bigint(20) default NULL COMMENT '创建用户',
  PRIMARY KEY  (`id`),
  KEY `user_view_space_id` (`space_id`),
  KEY `user_view_user_id` (`user_id`),
  CONSTRAINT `user_view_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_view_space_id` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=669 DEFAULT CHARSET=utf8 COMMENT='个人视图收藏表';

INSERT INTO `users` (`id`, `uic_id`, `username`, `name`, `email`, `locked`) VALUES 
  (1211,8488,'tianyusong','田雨松','tianyusong@baidu.com',0);