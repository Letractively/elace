SET FOREIGN_KEY_CHECKS=0;

#
# add enable_wiki column to plugin_roadmap_entity
#
ALTER table plugin_roadmap_entity  ADD `enable_wiki` tinyint(1) default '0';

#初始化原有数据的enable_wiki字段
update plugin_roadmap_entity set enable_wiki=0;