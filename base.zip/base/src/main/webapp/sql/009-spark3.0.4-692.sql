#添加记录进度条关闭状态值的字段，采用字符串的形式存储
SET FOREIGN_KEY_CHECKS=0;

#
# add status_property_values column to plugin_roadmap_space_mapping
# 记录方式同以逗号间隔的property value id
#
ALTER table plugin_roadmap_space_mapping  ADD `status_property_values` text COMMENT '关闭状态的propertyValueId的json串';
