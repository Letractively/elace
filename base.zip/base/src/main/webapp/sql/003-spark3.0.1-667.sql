SET FOREIGN_KEY_CHECKS=0;

#
# tables for the `wiki_plugin` :
#
CREATE TABLE `plugin_wiki_space_mapping` (
  `id` bigint(20) NOT NULL auto_increment COMMENT '映射ID',
  `space_id` bigint(20) NOT NULL COMMENT '空间ID',
  `space_view_id` bigint(20) NOT NULL COMMENT '用于跳转到wiki视图的空间视图ID',
  `available` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `plugin_wiki_space_mapping_space` (`space_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;