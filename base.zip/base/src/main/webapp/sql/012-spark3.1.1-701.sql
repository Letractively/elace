SET FOREIGN_KEY_CHECKS=0;

#
# add enable_wiki column to plugin_roadmap_entity
#
ALTER table plugin_roadmap_entity  ADD `sort` int(11) default NULL COMMENT '项目顺序号';