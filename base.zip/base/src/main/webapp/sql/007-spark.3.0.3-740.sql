SET FOREIGN_KEY_CHECKS=0;

#
# add writable column to space_view
# 0:false,1:true
#
ALTER table space_view  ADD `writeable` tinyint(1) default 1 COMMENT '是否删除';

#初始化原有数据的writeable字段，设为可删除
update space_view set writeable=1;

#将关联wiki页面的view设为不可删除
update space_view set writeable=0 where id in(select space_view_id from plugin_wiki_space_mapping);

#将关联roadmap页面的view设为不可删除
update space_view set writeable=0 where id in(select space_view_id from plugin_roadmap_space_mapping);