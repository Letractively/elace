SET FOREIGN_KEY_CHECKS=0;

#
#创建邮件规则表 记录邮件通知规则相关数据
#
CREATE TABLE `email_rule` (
  `id` bigint(20) NOT NULL auto_increment,
  `space_id` bigint(20) NOT NULL,
  `rule`    varchar(256) NOT NULL COMMENT '规则名' ,
  `enable`  bigint(20) default NULL COMMENT '是否选中或启用',
  `emails`  mediumtext COMMENT '描述',
  `modify_time` datetime default NULL COMMENT '最后更新时间',
  `last_modifier` varchar(256) default NULL COMMENT '最后更新人',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;