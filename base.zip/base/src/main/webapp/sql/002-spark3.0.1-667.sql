SET FOREIGN_KEY_CHECKS=0;

#
# add boolean column to card property in order to distinguish if one property is locked by a plugin.
#
ALTER table card_property ADD `available` tinyint(1) default 1;