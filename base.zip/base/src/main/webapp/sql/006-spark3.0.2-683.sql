SET FOREIGN_KEY_CHECKS=0;

#
# add wiki column to plugin-roadmap-entity
#
ALTER table plugin_roadmap_entity  ADD `wiki` varchar(500) ;