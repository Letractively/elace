SET FOREIGN_KEY_CHECKS=0;

#
# add writeable column to card_property
#
ALTER table card_property  ADD `writeable` tinyint(1) default '1';

#初始化原有数据的writeable字段，设为可修改
update card_property set writeable=1;

#将关联roadmap的card_property writeable字段设为不可修改
update card_property set writeable=0 where id in(select roadmap_property_id from plugin_roadmap_space_mapping);