SET FOREIGN_KEY_CHECKS=0;

#
# add properties column to card_template
#
ALTER table card_template  ADD `properties` text  COMMENT '卡片属性默认值';