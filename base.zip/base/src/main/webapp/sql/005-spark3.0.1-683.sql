SET FOREIGN_KEY_CHECKS=0;

#
# add boolean column to card property in order to distinguish if one property is locked by a plugin.
#
CREATE TABLE `plugin_roadmap_entity` (
  `id` bigint(20) NOT NULL auto_increment,
  `space_mapping_id` bigint(20) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` varchar(1024) default NULL,
  `status` bigint(20) default NULL,
  `dead_line` datetime default NULL,
  `icafe_project_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `plugin_roadmap_entity_space_mapping` (`space_mapping_id`),
  CONSTRAINT `plugin_roadmap_entity_space_mapping` FOREIGN KEY (`space_mapping_id`) REFERENCES `plugin_roadmap_space_mapping` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;